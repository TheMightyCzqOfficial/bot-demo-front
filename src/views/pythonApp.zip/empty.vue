<template>
    <div>
    </div>
</template>

<script>
export default {
  computed: {
  },
  data() {
    return {
    };
  },

  created() {

  },

  methods: {
  }
};
</script>

<style lang="scss" scoped>
</style>


