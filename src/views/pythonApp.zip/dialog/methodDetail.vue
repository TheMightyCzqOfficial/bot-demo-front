<template>
  <div>
    <!-- <span>登录账号配置</span> -->
    <el-card shadow="always" style="margin-top: 10px">
      <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="methodName"
        label="方法名称"
        min-width="180">
        <template slot-scope="scope">
          <el-link type="primary" @click="handleEdit(scope.row)">{{scope.row.methodName}}</el-link>
      </template>
        
      </el-table-column>
      <el-table-column
      prop="methodType"
        label="平台类型"
        min-width="150">
        <template slot-scope="scope">
        <el-tag
          :type="scope.row.methodType === '财务共享' ? 'primary' : 'success'">{{scope.row.methodType}}</el-tag>
      </template>
      </el-table-column>
      <el-table-column
        prop="userType"
        label="账号类型"
        min-width="150">
        <template slot-scope="scope">
          <el-tag type="primary" v-show="scope.row.userType=='个人账号'">{{scope.row.userType}}</el-tag>
          <el-tag type="success" v-show="scope.row.userType=='运维账号'">{{scope.row.userType}}</el-tag>
          <el-tag type="warning" v-show="scope.row.userType=='管理员账号'">{{scope.row.userType}}</el-tag>
          <el-tag type="danger" v-show="scope.row.userType=='审批员账号'">{{scope.row.userType}}</el-tag>
          <el-tag type="info" v-show="scope.row.userType=='远光二开账号'">{{scope.row.userType}}</el-tag>
      </template>
      </el-table-column>
      <el-table-column
        prop="stepCount"
        label="方法步骤总数"
        min-width="100">
      </el-table-column>
      <el-table-column
        prop="editable"
        label="是否可修改"
        min-width="100">
        <template slot-scope="scope">
        <el-tag
          :type="scope.row.editable  ? 'success' : 'danger'">{{scope.row.editable?"是":"否"}}</el-tag>
      </template>
      </el-table-column>
      <el-table-column
        prop="createDate"
        label="创建日期"
        min-width="180">
      </el-table-column>
      <el-table-column
      fixed="right"
      width="180">
      <template slot-scope="scope">
        <el-button type="success" size="small" @click="handleEdit(scope.row)">执行</el-button>
        <el-button type="success" size="small" @click="handleEdit(scope.row)">配置</el-button>
        <el-button type="danger" size="small" @click="handleEdit(scope.row)">删除</el-button>
      </template>
    </el-table-column>
    </el-table>
    </el-card>
  </div>
</template>

<script>
import { getMethodList } from "api/python";
import { getMethodData } from "api/python";
import { delMethod } from "api/python";
import { addMethod } from "api/python";
import { setMethod } from "api/python";
export default {
  props:[],
  computed: {},
  data() {
    return {
      rules: {
          username: [
            { required: true, message: '请输入用户名', trigger: 'blur' }
          ],
          password: [
            { required: true, message: '请输入密码', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '请选择账号平台', trigger: 'change'  }
          ]
        },
      tableData:[],
      userTypeOptions: [{
          value: '',
          label: ''
        }],
      methodTypeOptions: [{
          value: '',
          label: ''
        },],
      visible:false,
      usertype:true,
      userFormList:[],
      cwgxList:[],
      ygekList:[],
    };
  },

  created() {this.queryMethodList()},
  methods: {
    queryMethodList() {
      this.tableData=[]
      getMethodList().then(res=>{
        this.tableData=res.data
          console.log(res)
        }).catch((error) => {
              this.$message.error(error);
            });
    },
    handleEdit(row){

    }
  }
};
</script>

<style lang="scss" scoped>
.input{
  width: 350px;
}
</style>


